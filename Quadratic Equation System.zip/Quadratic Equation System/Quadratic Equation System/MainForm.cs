﻿/*
 * Created by SharpDevelop.
 * User: LaptopYar
 * Date: 14/04/1400
 * Time: 23:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Quadratic_Equation_System
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
//		void Button1_Click(object sender, EventArgs e)
//		{
//			// TODO: Implement Button1_Click
//		}
//		
//		void QE2_Click(object sender, EventArgs e)
//		{
//			// TODO: Implement QE2_Click
//		}
		
		void QE2_Click(object sender, EventArgs e)
		{
			new Form1().Show();
			this.Hide();
		}
	}
}
