﻿/*
 * Created by SharpDevelop.
 * User: LaptopYar
 * Date: 14/04/1400
 * Time: 23:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Quadratic_Equation_System
{
	partial class Form1
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.Button backPush;
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txt_a = new System.Windows.Forms.TextBox();
			this.txt_b = new System.Windows.Forms.TextBox();
			this.txt_c = new System.Windows.Forms.TextBox();
			this.confirmationPush = new System.Windows.Forms.Button();
			this.resEquation = new System.Windows.Forms.Label();
			backPush = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// backPush
			// 
			backPush.BackColor = System.Drawing.Color.Maroon;
			backPush.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			backPush.ForeColor = System.Drawing.SystemColors.ButtonFace;
			backPush.Location = new System.Drawing.Point(155, 270);
			backPush.Name = "backPush";
			backPush.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			backPush.Size = new System.Drawing.Size(125, 50);
			backPush.TabIndex = 12;
			backPush.Text = "برگشت";
			backPush.UseVisualStyleBackColor = false;
			backPush.Click += new System.EventHandler(this.BackPush_Click);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(648, 57);
			this.label1.TabIndex = 2;
			this.label1.Text = "معادله درجه دوم";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label2.Location = new System.Drawing.Point(12, 76);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(648, 359);
			this.label2.TabIndex = 3;
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
			this.label3.Location = new System.Drawing.Point(491, 154);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(143, 31);
			this.label3.TabIndex = 4;
			this.label3.Text = "ضریب اول (a)";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
			this.label4.Location = new System.Drawing.Point(491, 202);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(143, 30);
			this.label4.TabIndex = 5;
			this.label4.Text = "ضریب دوم (b)";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
			this.label5.Location = new System.Drawing.Point(491, 249);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(143, 29);
			this.label5.TabIndex = 6;
			this.label5.Text = "ضریب سوم (c)";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(12, 76);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(648, 48);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox1.TabIndex = 7;
			this.pictureBox1.TabStop = false;
			// 
			// txt_a
			// 
			this.txt_a.BackColor = System.Drawing.Color.MintCream;
			this.txt_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.txt_a.ForeColor = System.Drawing.SystemColors.Highlight;
			this.txt_a.Location = new System.Drawing.Point(310, 154);
			this.txt_a.Multiline = true;
			this.txt_a.Name = "txt_a";
			this.txt_a.Size = new System.Drawing.Size(175, 31);
			this.txt_a.TabIndex = 8;
			// 
			// txt_b
			// 
			this.txt_b.BackColor = System.Drawing.Color.MintCream;
			this.txt_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.txt_b.ForeColor = System.Drawing.SystemColors.Highlight;
			this.txt_b.Location = new System.Drawing.Point(310, 202);
			this.txt_b.Multiline = true;
			this.txt_b.Name = "txt_b";
			this.txt_b.Size = new System.Drawing.Size(175, 30);
			this.txt_b.TabIndex = 9;
			// 
			// txt_c
			// 
			this.txt_c.BackColor = System.Drawing.Color.MintCream;
			this.txt_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.txt_c.ForeColor = System.Drawing.SystemColors.Highlight;
			this.txt_c.Location = new System.Drawing.Point(310, 249);
			this.txt_c.Multiline = true;
			this.txt_c.Name = "txt_c";
			this.txt_c.Size = new System.Drawing.Size(175, 29);
			this.txt_c.TabIndex = 10;
			// 
			// confirmationPush
			// 
			this.confirmationPush.BackColor = System.Drawing.Color.Green;
			this.confirmationPush.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.confirmationPush.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.confirmationPush.Location = new System.Drawing.Point(24, 270);
			this.confirmationPush.Name = "confirmationPush";
			this.confirmationPush.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.confirmationPush.Size = new System.Drawing.Size(125, 50);
			this.confirmationPush.TabIndex = 11;
			this.confirmationPush.Text = "تایید";
			this.confirmationPush.UseVisualStyleBackColor = false;
			this.confirmationPush.Click += new System.EventHandler(this.ConfirmationPush_Click);
			// 
			// resEquation
			// 
			this.resEquation.Enabled = false;
			this.resEquation.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
			this.resEquation.ForeColor = System.Drawing.Color.White;
			this.resEquation.Location = new System.Drawing.Point(29, 351);
			this.resEquation.Name = "resEquation";
			this.resEquation.Size = new System.Drawing.Size(604, 74);
			this.resEquation.TabIndex = 13;
			this.resEquation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.resEquation.Click += new System.EventHandler(this.ResEquation_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.ClientSize = new System.Drawing.Size(672, 444);
			this.Controls.Add(this.resEquation);
			this.Controls.Add(backPush);
			this.Controls.Add(this.confirmationPush);
			this.Controls.Add(this.txt_c);
			this.Controls.Add(this.txt_b);
			this.Controls.Add(this.txt_a);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "معادله درجه دوم";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label resEquation;
		private System.Windows.Forms.Button confirmationPush;
		private System.Windows.Forms.TextBox txt_c;
		private System.Windows.Forms.TextBox txt_b;
		private System.Windows.Forms.TextBox txt_a;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
	}
}
